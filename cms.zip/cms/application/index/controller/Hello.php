<?php

namespace app\index\controller;

use think\Controller;

class Hello extends Controller
{
	
	function index(){
		return "Hello";
	}
}