<?php
namespace app\admin\controller;

class Conf{

	public function conflst(){
		return view();
	}

	public function lst(){
		return view();
	}
	public function add(){

		if(request()->isPost()){
			//$data = input('post.');
			$add = db('tp_conf')->insert($data);
			var_dump($data);
		}

		return view();
	}
	public function edit(){
		return view();
	}
}
